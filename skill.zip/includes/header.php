<?php
// Start the session
session_start();
$menu ="<div class='container-fluid'>
<div class='row'>
  <div class='col-4 hamburger'>
    <img id='hamburger' src='https://raw.githubusercontent.com/Zulinov/skillsProjects/main/hamburger.png' width='50px' height='50px'>  
    <!--Affichage du menu -->
    <nav class='menu'>
      <ul>
        <li>Home</li>
        <li>Book Trip</li>
        <li>Admin Login</li>
      </ul>
    </nav>
  </div>
  <div class='col-4 titre_bar'>
    Halifax Come and Kayak
  </div>
  <div class='col-4 paddle'>
    <img  src='https://raw.githubusercontent.com/Zulinov/skillsProjects/main/paddle-white.png' width='50px' height='50px'>  
  </div>
</div>
</div>
";
